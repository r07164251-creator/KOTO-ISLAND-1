package studio.koto.island

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/**
 * Single command pipeline shared by the overlay mic and the in-app mic:
 * recognized text -> parse -> execute (local, offline) -> reply -> history.
 * handled=false means "not a system command": the caller hands it to the web layer (math / notes / AI).
 */
class CommandEngine(private val c: Context) {
    class Res(val handled: Boolean, val reply: String = "", val ok: Boolean = true, val name: String = "")

    private val sp = c.getSharedPreferences("koto", Context.MODE_PRIVATE)
    val lang: String get() = sp.getString("lang", "ru") ?: "ru"
    fun tag() = when (lang) { "uk" -> "uk-UA"; "en" -> "en-US"; else -> "ru-RU" }
    fun tr(ru: String, uk: String, en: String) = when (lang) { "uk" -> uk; "en" -> en; else -> ru }
    private fun fmt() = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
    fun err(n: String) { sp.edit().putString("lasterr", "$n @ ${fmt()}").apply() }

    private val alias = mapOf("ютуб" to "youtube", "ютюб" to "youtube", "хром" to "chrome", "настройки" to "settings", "налаштування" to "settings")
    private val reSearch = Regex("^(?:напиши в браузере|найди в браузере|найди в интернете|напиши в браузері|знайди в браузері|search (?:the )?(?:web|browser) for|write in (?:the )?browser)\\s+(.+)$")
    private val reYt = Regex("^(?:открой |запусти |відкрий |open )?(?:ютуб|ютюб|youtube)\\s+(.+)$")
    private val reTwitch = Regex("^(?:открой |запусти |відкрий |open |launch )?(?:твич|twitch)$")
    private val reOpen = Regex("^(?:открой|запусти|відкрий|open|launch)\\s+(.+)$")

    fun run(raw: String): Res {
        val q = raw.trim().lowercase().replace(Regex("^(котость|котосте|kotosty)[,!.\\s]*"), "").trim()
        val r = try { exec(q) } catch (e: SecurityException) {
            Res(true, tr("Нет доступа к запуску", "Немає доступу до запуску", "Launch not allowed"), false, "denied")
        }
        if (r.handled) {
            val a = JSONArray(sp.getString("hist", "[]"))
            a.put(JSONObject().put("t", System.currentTimeMillis()).put("heard", raw.take(120)).put("cmd", r.name).put("ok", r.ok))
            val keep = JSONArray()
            for (i in maxOf(0, a.length() - 30) until a.length()) keep.put(a.get(i))
            sp.edit().putString("hist", keep.toString()).apply()
            if (!r.ok) err(r.name)
        }
        return r
    }

    private fun exec(q: String): Res {
        reSearch.find(q)?.let { return web("https://www.google.com/search?q=" + enc(it.groupValues[1])) }
        reYt.find(q)?.let { return yt(it.groupValues[1]) }
        if (reTwitch.matches(q)) return twitch()
        val loc = Locale.forLanguageTag(tag())
        if (Regex("который час|скільки часу|котра година|what time").containsMatchIn(q))
            return Res(true, DateFormat.getTimeInstance(DateFormat.SHORT, loc).format(Date()), true, "time")
        if (Regex("какая сегодня дата|какое сегодня число|яка сьогодні дата|today'?s date|what'?s the date").containsMatchIn(q))
            return Res(true, DateFormat.getDateInstance(DateFormat.LONG, loc).format(Date()), true, "date")
        if (Regex("батаре|заряд|battery").containsMatchIn(q)) {
            val p = (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return Res(true, "$p%", true, "battery")
        }
        reOpen.find(q)?.let { return open(it.groupValues[1].trim()) }
        return Res(false)
    }

    private fun enc(s: String) = URLEncoder.encode(s.trim().take(200), "UTF-8")

    private fun view(url: String, pkg: String? = null): Boolean {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.setPackage(pkg)
        return try { c.startActivity(i); true } catch (e: ActivityNotFoundException) { false }
    }

    private fun web(url: String): Res {
        val ok = view(url)
        return Res(true, if (ok) "✓" else tr("Браузер не найден", "Браузер не знайдено", "No browser found"), ok, "search")
    }

    private fun yt(q: String): Res {
        val u = "https://www.youtube.com/results?search_query=" + enc(q)
        val ok = view(u, "com.google.android.youtube") || view(u)   // app first, browser if YouTube is missing
        return Res(true, if (ok) "YouTube: " + q.take(30) else tr("Не удалось открыть YouTube", "Не вдалося відкрити YouTube", "Can't open YouTube"), ok, "youtube_search")
    }

    private fun twitch(): Res {
        val i = c.packageManager.getLaunchIntentForPackage("tv.twitch.android.app")
        val ok = if (i != null) { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } else view("https://www.twitch.tv")
        return Res(true, if (ok) "Twitch" else tr("Не удалось открыть Twitch", "Не вдалося відкрити Twitch", "Can't open Twitch"), ok, "twitch")
    }

    private fun open(a: String): Res {
        if (Regex("заметк|нотатк|^notes?$").containsMatchIn(a)) return Res(false)   // in-app screen, handled by the web layer
        val pm = c.packageManager
        val key = alias[a] ?: a
        val names = if (key == "settings") listOf("settings", "настройки", "налаштування") else listOf(key)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { ri -> val l = ri.loadLabel(pm).toString().lowercase(); names.any { l.contains(it) } }
        val i = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (i == null) return Res(true, tr("Мур, я не нашёл это приложение", "Мур, я не знайшов цей застосунок", "Purr, I couldn't find that app"), false, "open_app")
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return Res(true, "✓ " + a.take(24), true, "open_app")
    }
}
