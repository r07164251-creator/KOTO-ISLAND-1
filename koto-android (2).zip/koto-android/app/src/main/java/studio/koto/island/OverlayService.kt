package studio.koto.island

import android.Manifest
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

/**
 * One native overlay window holding [mic][island] (no WebView, no JS in the overlay).
 * Dragging uses raw screen coordinates and at most one layout update per frame; position is stored as screen fractions.
 */
class OverlayService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var inst: OverlayService? = null
        private val BG = 0xE60A0A0F.toInt()
        private val LAUNCH = setOf("open_app", "search", "youtube_search", "twitch")
    }

    private lateinit var wm: WindowManager
    private lateinit var pill: FrameLayout
    private lateinit var face: KotostView
    private lateinit var clock: TextView
    private lateinit var mic: TextView
    private lateinit var micBg: GradientDrawable
    private var root: LinearLayout? = null
    private var open = false
    private var listening = false
    private var sr: SpeechRecognizer? = null
    private var anim: ValueAnimator? = null
    private var pulse: ValueAnimator? = null
    private var queued = false
    private var msgUntil = 0L

    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private val sp by lazy { getSharedPreferences("koto", Context.MODE_PRIVATE) }
    private val engine by lazy { CommandEngine(applicationContext) }
    private val slop by lazy { ViewConfiguration.get(this).scaledTouchSlop }
    private val d: Float get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private fun curW() = dp(56) + pill.layoutParams.width          // paddings + mic + gap + island (deterministic, no layout lag)
    private fun curH() = dp(8) + maxOf(dp(40), pill.layoutParams.height)

    private val frame = Choreographer.FrameCallback { queued = false; upd() }
    private val revert = Runnable { face.state(0); msgUntil = 0; tick(); setOpen(false) }
    private val ticker: Runnable = object : Runnable { override fun run() { tick(); root?.postDelayed(this, 30_000) } }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() { super.onCreate(); inst = this }

    // startForeground must run on every start (also re-evaluates the microphone type after the permission was granted).
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        fg()
        if (!Settings.canDrawOverlays(this)) { engine.err("overlay_denied"); stopSelf(); return START_NOT_STICKY }
        if (root == null) build()                                    // single window guard
        return START_NOT_STICKY
    }

    private fun fg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("koto", "KOTO ISLAND", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "koto").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("KOTO ISLAND").build()
        if (Build.VERSION.SDK_INT >= 34) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, t)
        } else startForeground(1, n)
    }

    private fun build() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        micBg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(BG); setStroke(dp(1), 0x33FFFFFF) }
        mic = TextView(this).apply {
            text = "🎙"; textSize = 18f; gravity = Gravity.CENTER; background = micBg
            contentDescription = "KOTO microphone"
            setOnClickListener { onMic() }
        }
        face = KotostView(this)
        clock = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 16f; maxLines = 1; maxWidth = dp(112); alpha = 0f
            ellipsize = TextUtils.TruncateAt.END
        }
        pill = FrameLayout(this).apply {
            background = GradientDrawable().apply { cornerRadius = dp(32).toFloat(); setColor(BG); setStroke(dp(1), 0x33FFFFFF) }
            addView(face, FrameLayout.LayoutParams(dp(36), dp(36)).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; marginStart = dp(26) })
            addView(clock, FrameLayout.LayoutParams(-2, -2).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; marginEnd = dp(16) })
            setOnTouchListener(Drag())
        }
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(mic, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(8) })
            addView(pill, LinearLayout.LayoutParams(dp(88), dp(40)))
        }
        root = r
        place()
        wm.addView(r, lp)
        running = true
    }

    // ---- position -------------------------------------------------------------------------------------------
    private fun place() {
        val m = resources.displayMetrics
        val cx = sp.getFloat("px", .5f) * m.widthPixels                       // default: horizontal centre
        val y = if (sp.contains("py")) sp.getFloat("py", 0f) * m.heightPixels else dp(6).toFloat()   // default: top
        lp.x = (cx - curW() / 2f).toInt(); lp.y = y.toInt(); clamp()
    }

    private fun clamp() {
        val m = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, maxOf(0, m.widthPixels - curW()))
        lp.y = lp.y.coerceIn(0, maxOf(0, m.heightPixels - curH()))
    }

    private fun upd() { root?.let { if (it.isAttachedToWindow) wm.updateViewLayout(it, lp) } }
    private fun queueUpdate() { if (!queued) { queued = true; Choreographer.getInstance().postFrameCallback(frame) } }

    private fun save(x: Int, y: Int) {
        val m = resources.displayMetrics
        sp.edit().putFloat("px", (x + curW() / 2f) / m.widthPixels).putFloat("py", y.toFloat() / m.heightPixels).apply()
    }

    fun reset() { root?.post { sp.edit().remove("px").remove("py").apply(); place(); upd() } }

    private fun snap() {
        val m = resources.displayMetrics
        val w = curW()
        val mid = m.widthPixels / 2
        val to = when {
            Math.abs(lp.x + w / 2 - mid) < dp(48) -> mid - w / 2          // soft magnet to the centre
            lp.x < dp(40) -> 0
            lp.x + w > m.widthPixels - dp(40) -> m.widthPixels - w        // ...or to an edge
            else -> lp.x
        }
        save(to, lp.y)
        anim?.cancel()
        anim = ValueAnimator.ofInt(lp.x, to).apply {
            duration = 240; interpolator = DecelerateInterpolator()
            addUpdateListener { lp.x = it.animatedValue as Int; upd() }
            start()
        }
    }

    private inner class Drag : View.OnTouchListener {
        var dx0 = 0f; var dy0 = 0f; var x0 = 0; var y0 = 0; var moved = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    anim?.cancel(); dx0 = e.rawX; dy0 = e.rawY; x0 = lp.x; y0 = lp.y; moved = false
                    v.animate().scaleX(.94f).scaleY(.94f).setDuration(110).start()
                }
                MotionEvent.ACTION_MOVE -> if (!sp.getBoolean("lock", false)) {
                    val dx = e.rawX - dx0; val dy = e.rawY - dy0
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > slop) moved = true
                    if (moved) { lp.x = x0 + dx.toInt(); lp.y = y0 + dy.toInt(); clamp(); queueUpdate() }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
                    if (moved) { snap(); moved = false } else if (e.actionMasked == MotionEvent.ACTION_UP) setOpen(!open)
                }
            }
            return true
        }
    }

    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); if (root != null) { place(); upd() } }

    // ---- island open / close ------------------------------------------------------------------------------------
    private fun haptic() { if (sp.getBoolean("haptic", true)) root?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }

    private fun tick() { if (System.currentTimeMillis() >= msgUntil) clock.text = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()) }

    private fun say(m: String, ms: Long = 2500) {
        clock.text = m; msgUntil = System.currentTimeMillis() + ms
        root?.removeCallbacks(revert); root?.postDelayed(revert, ms)
    }

    private fun setOpen(o: Boolean) {
        if (o == open || root == null) return
        open = o; haptic()
        val w0 = pill.layoutParams.width; val w1 = dp(if (o) 190 else 88)
        val h0 = pill.layoutParams.height; val h1 = dp(if (o) 64 else 40)
        val cx = lp.x + curW() / 2
        root?.removeCallbacks(ticker)
        if (o) { tick(); root?.postDelayed(ticker, 30_000) }              // clock timer only while expanded
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 260
            interpolator = if (o) OvershootInterpolator(.8f) else DecelerateInterpolator()
            addUpdateListener {
                val v = it.animatedValue as Float
                pill.layoutParams.width = (w0 + (w1 - w0) * v).toInt()
                pill.layoutParams.height = (h0 + (h1 - h0) * v).toInt()
                pill.requestLayout()
                val k = if (o) v else 1 - v
                face.translationX = -dp(12) * k
                clock.alpha = k.coerceIn(0f, 1f)
                lp.x = cx - curW() / 2; clamp(); upd()
            }
            start()
        }
    }

    // ---- microphone -> CommandEngine ---------------------------------------------------------------------------
    private fun glow(on: Boolean) {
        pulse?.cancel(); pulse = null
        micBg.setColor(if (on) 0xFF6D4AFF.toInt() else BG)
        mic.scaleX = 1f; mic.scaleY = 1f
        if (on) pulse = ValueAnimator.ofFloat(1f, 1.15f).apply {
            duration = 700; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { mic.scaleX = it.animatedValue as Float; mic.scaleY = it.animatedValue as Float }
            start()
        }
    }

    private fun txt(b: Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private fun onMic() {
        if (listening) { sr?.stopListening(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            setOpen(true); face.state(4)
            say(engine.tr("Нужен доступ к микрофону — открываю запрос", "Потрібен доступ до мікрофона — відкриваю запит", "Microphone access needed — opening request"), 3500)
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("mic", true))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            engine.err("speech_unavailable"); setOpen(true); face.state(4)
            say(engine.tr("Распознавание речи недоступно", "Розпізнавання мовлення недоступне", "Speech recognition unavailable")); return
        }
        listening = true; glow(true); face.state(1); haptic()
        root?.removeCallbacks(revert); msgUntil = 0; setOpen(true)
        clock.text = engine.tr("Слушаю…", "Слухаю…", "Listening…")
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onPartialResults(p: Bundle?) { txt(p)?.let { clock.text = it } }
            override fun onResults(p: Bundle?) { finish(); val t = txt(p); if (t.isNullOrBlank()) fail(7) else exec(t) }
            override fun onError(e: Int) { finish(); fail(e) }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { face.state(2) }
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, engine.tag())
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }

    private fun finish() {
        listening = false; glow(false)
        sr?.let { s -> root?.post { s.destroy() } }; sr = null            // never keep the recognizer (or the mic) alive after a result
    }

    private fun fail(e: Int) {
        engine.err("speech$e"); face.state(4)
        say(when (e) {
            6, 7 -> engine.tr("Не расслышал, попробуй ещё раз", "Не розчув, спробуй ще раз", "Didn't catch that")
            9 -> engine.tr("Нужен доступ к микрофону", "Потрібен доступ до мікрофона", "Microphone access needed")
            12, 13 -> engine.tr("Нет языкового пакета распознавания", "Немає мовного пакета розпізнавання", "Speech language pack missing")
            1, 2, 4 -> engine.tr("Нужен интернет для распознавания", "Потрібен інтернет для розпізнавання", "Speech needs internet")
            else -> engine.tr("Ошибка распознавания ($e)", "Помилка розпізнавання ($e)", "Recognition error ($e)")
        })
    }

    private fun exec(text: String) {
        face.state(2)
        val r = engine.run(text)
        if (!r.handled) {   // math / notes / AI live in the web layer: bring the app forward with the text
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("cmd", text.take(300)))
            say(engine.tr("Открываю приложение…", "Відкриваю застосунок…", "Opening the app…"), 1500); return
        }
        haptic()
        if (r.ok && r.name in LAUNCH) {   // another app comes forward: fold the island, keep the service running
            face.state(3); root?.removeCallbacks(revert); setOpen(false)
            root?.postDelayed({ face.state(0) }, 1500)
        } else { face.state(if (r.ok) 3 else 4); say(r.reply) }
    }

    override fun onDestroy() {
        Choreographer.getInstance().removeFrameCallback(frame)
        anim?.cancel(); pulse?.cancel(); sr?.destroy(); sr = null
        root?.let { it.removeCallbacks(revert); it.removeCallbacks(ticker); if (it.isAttachedToWindow) wm.removeView(it) }
        root = null; running = false; inst = null
        super.onDestroy()
    }
}
