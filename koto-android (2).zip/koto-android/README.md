# KOTO ISLAND V2
Kotlin + WebView (UI in app/src/main/assets/index.html), Gradle 8.7, Java 17, AGP 8.5.2 (unchanged).
**Overlay:** native service, one window [mic][island], raw-coordinate drag (1 layout update/frame), snap to centre/edges, position saved as screen fractions, lock + reset in Settings.
**Voice:** mic beside the island -> SpeechRecognizer -> CommandEngine.kt (one pipeline for overlay and in-app mic) -> reply + history. No background listening.
**Commands:** time, date, battery, open app, "напиши в браузере <q>", "Ютуб <q>", "Twitch"; math / notes / AI questions are passed to the app.
**Permissions:** INTERNET, SYSTEM_ALERT_WINDOW, RECORD_AUDIO, FOREGROUND_SERVICE(+SPECIAL_USE, +MICROPHONE), POST_NOTIFICATIONS.
**Build:** push this folder's contents to GitHub -> Actions -> "Build APK" -> artifact app-debug.
