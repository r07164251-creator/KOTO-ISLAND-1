package studio.koto.island

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

const val HOST = "appassets.androidplatform.net"

/** API key lives in process memory only; never written to disk. */
object Mem { @Volatile var key = "" }

/** Serves bundled assets over https://HOST and blocks navigation to any other site. */
fun assetClient(c: Context): WebViewClient {
    val loader = WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(c)).build()
    return object : WebViewClient() {
        override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = r.url.host != HOST
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var sr: SpeechRecognizer? = null
    private var lang = "en-US"

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) listen() else send("voice", JSONObject().put("s", "denied"))
    }

    private fun send(ev: String, o: JSONObject) {
        web.post { web.evaluateJavascript("window.onKoto&&window.onKoto(${JSONObject.quote(ev)},$o)", null) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.webViewClient = assetClient(this)
        web.addJavascriptInterface(Bridge(), "KotoNative")
        web.loadUrl("https://$HOST/assets/index.html")
    }

    // Web layer re-checks permissions every time the user comes back (e.g. from system Settings).
    override fun onResume() { super.onResume(); if (::web.isInitialized) send("resume", JSONObject()) }

    override fun onDestroy() { sr?.destroy(); web.destroy(); super.onDestroy() }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { send("voice", JSONObject().put("s", "unavailable")); return }
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            fun txt(b: Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            override fun onReadyForSpeech(p: Bundle?) = send("voice", JSONObject().put("s", "listening"))
            override fun onPartialResults(p: Bundle?) = send("voice", JSONObject().put("s", "partial").put("text", txt(p)))
            override fun onResults(p: Bundle?) = send("voice", JSONObject().put("s", "result").put("text", txt(p)))
            override fun onEndOfSpeech() = send("voice", JSONObject().put("s", "processing"))
            override fun onError(e: Int) = send("voice", JSONObject().put("s", "error").put("code", e))
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }

    /** Whitelisted actions only; every argument is validated. Microphone starts only on explicit startVoice(). */
    inner class Bridge {
        @JavascriptInterface fun overlay() = if (Settings.canDrawOverlays(this@MainActivity)) "granted" else "denied"

        @JavascriptInterface fun requestOverlay() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun startOverlay(): Boolean {
            if (!Settings.canDrawOverlays(this@MainActivity)) return false
            ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, OverlayService::class.java))
            return true
        }

        @JavascriptInterface fun stopOverlay() { stopService(Intent(this@MainActivity, OverlayService::class.java)) }

        @JavascriptInterface fun mic() =
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) "granted" else "denied"

        @JavascriptInterface fun startVoice(l: String) = runOnUiThread {
            if (l in setOf("ru-RU", "uk-UA", "en-US")) lang = l
            if (mic() == "granted") listen() else micPerm.launch(Manifest.permission.RECORD_AUDIO)
        }

        @JavascriptInterface fun stopVoice() = runOnUiThread { sr?.stopListening() }

        @JavascriptInterface fun openApp(q: String): Boolean {
            val n = q.trim().lowercase().take(60)
            if (n.isEmpty()) return false
            val pm = packageManager
            @Suppress("DEPRECATION")
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) } ?: return false
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
            runOnUiThread { startActivity(i) }
            return true
        }

        @JavascriptInterface fun battery() =
            (getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        @JavascriptInterface fun setKey(k: String) { Mem.key = k.take(400) }
    }
}
