package studio.koto.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

/** Floating island: a small WebView window (TYPE_APPLICATION_OVERLAY) sized to its content, so touches elsewhere pass through. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var web: WebView? = null
    private var mode = "mini"
    private val d: Float get() = resources.displayMetrics.density
    private val sp by lazy { getSharedPreferences("koto", Context.MODE_PRIVATE) }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("koto", "KOTO ISLAND", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "koto").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("KOTO ISLAND").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            0, 0, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        lp.x = sp.getInt("x", 0)
        lp.y = sp.getInt("y", (120 * d).toInt())

        val w = WebView(this)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = assetClient(this)
        w.addJavascriptInterface(OB(), "KotoOverlay")
        w.loadUrl("https://$HOST/assets/index.html?overlay=1")
        web = w
        size()
        wm.addView(w, lp)
    }

    private fun size() {
        val (w, h) = when (mode) { "expanded" -> 320 to 360; "hidden" -> 16 to 56; else -> 150 to 48 }
        val m = resources.displayMetrics
        lp.width = minOf((w * d).toInt(), m.widthPixels - (16 * d).toInt())
        lp.height = (h * d).toInt()
        // keyboard input only while expanded
        lp.flags = if (mode == "expanded") lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                   else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        clamp(); upd()
    }

    private fun clamp() {
        val m = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, maxOf(0, m.widthPixels - lp.width))
        lp.y = lp.y.coerceIn(0, maxOf(0, m.heightPixels - lp.height))
    }

    private fun upd() { web?.let { if (it.isAttachedToWindow) wm.updateViewLayout(it, lp) } }

    private fun snap() {
        val m = resources.displayMetrics
        val to = if (lp.x + lp.width / 2 < m.widthPixels / 2) 0 else m.widthPixels - lp.width
        sp.edit().putInt("x", to).putInt("y", lp.y).apply()
        ValueAnimator.ofInt(lp.x, to).apply {
            duration = 220
            addUpdateListener { lp.x = it.animatedValue as Int; upd() }
            start()
        }
    }

    // Re-clamp the window after rotation / size changes.
    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); size() }

    override fun onDestroy() {
        web?.let { if (it.isAttachedToWindow) wm.removeView(it); it.destroy() }
        web = null
        super.onDestroy()
    }

    inner class OB {
        @JavascriptInterface fun getKey() = Mem.key
        @JavascriptInterface fun setMode(m: String) { if (m in setOf("mini", "expanded", "hidden")) web?.post { mode = m; size() } }
        @JavascriptInterface fun drag(dx: Double, dy: Double) {
            if (!dx.isFinite() || !dy.isFinite() || Math.abs(dx) > 2000 || Math.abs(dy) > 2000) return
            web?.post { lp.x += (dx * d).toInt(); lp.y += (dy * d).toInt(); clamp(); upd() }
        }
        @JavascriptInterface fun dragEnd() { web?.post { snap() } }
        @JavascriptInterface fun close() { web?.post { stopSelf() } }
    }
}
