plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "studio.koto.island"
    compileSdk = 34
    defaultConfig { applicationId = "studio.koto.island"; minSdk = 26; targetSdk = 34; versionCode = 2; versionName = "1.5" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.webkit:webkit:1.11.0")
}
