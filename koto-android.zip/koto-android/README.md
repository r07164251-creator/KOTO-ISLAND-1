# KOTO ISLAND V1.5 — Android project
1. Android Studio (Koala+) → Open this folder → Sync (JDK 17).
2. Run on a device (Android 8.0+). Web UI lives in app/src/main/assets/index.html — edit it there.
3. Build APK: Build → Build APK(s) (debug) or Generate Signed Bundle/APK (release).
First launch: ENABLE OVERLAY opens system Settings; status is re-checked on return. Mic permission is asked on first 🎙 tap.
Open items: see the reply notes. Not compiled or device-tested by the author of this file.
