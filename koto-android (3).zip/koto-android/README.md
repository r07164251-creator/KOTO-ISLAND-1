# KOTO ISLAND V2
Kotlin + WebView (UI in app/src/main/assets/index.html), Gradle 8.7, Java 17, AGP 8.5.2 (unchanged).
**Overlay:** native service, one window [mic][island], raw-coordinate drag (1 layout update/frame), snap to centre/edges, position saved as screen fractions, lock + reset in Settings.
**Voice:** mic beside the island -> SpeechRecognizer -> CommandEngine.kt (one pipeline for overlay and in-app mic) -> reply + history. No background listening.
**Commands:** time, date, battery, open app, "напиши в браузере <q>", "Ютуб <q>", "Twitch"; math / notes / AI questions are passed to the app.
**Permissions:** INTERNET, SYSTEM_ALERT_WINDOW, RECORD_AUDIO, FOREGROUND_SERVICE(+SPECIAL_USE, +MICROPHONE), POST_NOTIFICATIONS.
**Build:** push this folder's contents to GitHub -> Actions -> "Build APK" -> artifact app-debug.

## V2.1
Voice speed: one recognizer instance reused (no re-create per press), shorter silence/endpointing extras, offline preferred, last partial result used if the final one is late, 12 s watchdog, stale-callback guard (no duplicate commands), recognizer released after 60 s idle.
KOTO QUICK (home card ⚡): battery, volume, sound mode, brightness; edit mode = remove / add back / size S-M-L / reorder. Brightness needs the WRITE_SETTINGS special access, silent mode needs Do Not Disturb access; both are requested only when used.
Tamagotchi (opt-in): charging feeds Kotosty, screen off = sleep, touch reactions, boredom, rare vibration (toggle, 20 min limit, off in DND). Kotosty colour: 6 presets + roll.

## V2.2
Fixed: infinite recursion in the Tamagotchi mood code (V2.1 would crash the overlay on start); Kotosty is restored to idle after a voice reply.
CommandEngine is now table-driven (Cmds.kt: phrases RU/UK/EN, unit-tested in CmdsTest). 38 of the 50 requested commands: phone 10, calendar + days-until, music 6, pet 7, island 6, AI templates 7 (need KOTO AI + text after the command).
Not done: notes/tasks/reminders (11-17, 20), now-playing + shuffle (25, 27), pet collection (35), favourite apps (43). Wake word: "Кото" / "Котость".
Direct toggling is impossible on Android for battery saver, Wi-Fi, Bluetooth (the matching settings screen opens); silent/DND needs the user's Do Not Disturb access; music keys reach only the active media session.
