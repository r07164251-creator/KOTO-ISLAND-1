package studio.koto.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import androidx.core.graphics.ColorUtils
import java.util.Random

/** Kotosty: ears, two eyes, a mouth. Poses are blended with short animators; the only recurring work is one blink timer every 2.5-5 s. */
class KotostView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    var head = 0xFFF2EFFF.toInt()
    var glowColor = 0xFFFFD43B.toInt()
    private val cur = floatArrayOf(1f, 0f, 0f, .35f, 0f, 0f, 0f)   // eye openness, look x, look y, smile, ear raise
    private var blink = 0f
    private var anim: ValueAnimator? = null
    private val rnd = Random()
    private val idleTick = object : Runnable {
        override fun run() {
            if (cur[0] > .6f) ValueAnimator.ofFloat(0f, 1f, 0f).apply {
                duration = 160
                addUpdateListener { blink = it.animatedValue as Float; invalidate() }
                start()
            }
            if (rnd.nextInt(3) == 0 && cur[3] > 0f) to(floatArrayOf(cur[0], rnd.nextFloat() * 2 - 1, 0f, cur[3], cur[4], cur[5], cur[6]), 280)
            postDelayed(this, 2500L + rnd.nextInt(2500))
        }
    }

    fun to(t: FloatArray, ms: Long = 200) {
        anim?.cancel()
        val f = cur.copyOf()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            addUpdateListener { v ->
                val k = v.animatedValue as Float
                for (i in cur.indices) cur[i] = f[i] + (t[i] - f[i]) * k
                invalidate()
            }
            start()
        }
    }

    /** 0 idle, 1 listening, 2 thinking, 3 delighted, 4 error, 5 sleep, 6 hungry, 7 angry, 8 bored, 9 purr, 10 curious. Pose = [eye, lookX, lookY, smile, ear, tilt, glow] */
    fun state(s: Int, glow: Float = 0f, ms: Long = 300) = to(when (s) {
        1 -> floatArrayOf(1.2f, 0f, 0f, .1f, 1f, 0f, glow)
        2 -> floatArrayOf(.9f, .8f, -.6f, 0f, .4f, 0f, glow)
        3 -> floatArrayOf(.25f, 0f, 0f, 1f, .6f, 0f, glow)
        4 -> floatArrayOf(.8f, 0f, .4f, -.7f, 0f, 0f, glow)
        5 -> floatArrayOf(.06f, 0f, .3f, .2f, -.2f, 6f, glow)
        6 -> floatArrayOf(.7f, 0f, .6f, -.5f, -.5f, 0f, glow)
        7 -> floatArrayOf(.5f, 0f, 0f, -1f, -.9f, 0f, glow)
        8 -> floatArrayOf(.4f, .5f, .3f, 0f, -.3f, -5f, glow)
        9 -> floatArrayOf(.12f, 0f, 0f, 1f, .4f, 0f, glow)
        10 -> floatArrayOf(1.25f, .7f, -.3f, .2f, 1f, 8f, glow)
        else -> floatArrayOf(1f, 0f, 0f, .35f, 0f, 0f, glow)
    }, ms)

    override fun onAttachedToWindow() { super.onAttachedToWindow(); postDelayed(idleTick, 2500) }
    override fun onDetachedFromWindow() { removeCallbacks(idleTick); anim?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val u = width / 36f
        cv.save()
        cv.rotate(cur[5], width / 2f, height * .7f)
        p.style = Paint.Style.FILL
        p.color = ColorUtils.blendARGB(head, glowColor, cur[6] * .6f)
        for (s in intArrayOf(-1, 1)) {
            path.reset()
            path.moveTo((18 + s * 14) * u, 15 * u)
            path.lineTo((18 + s * 12) * u, (5 - 3 * cur[4]) * u)
            path.lineTo((18 + s * 5) * u, 12 * u)
            path.close()
            cv.drawPath(path, p)
        }
        rect.set(3 * u, 10 * u, 33 * u, 34 * u)
        cv.drawRoundRect(rect, 12 * u, 12 * u, p)
        p.color = 0xFF15151C.toInt()
        val ry = maxOf(.5f, 3.4f * cur[0] * (1 - blink))
        for (s in intArrayOf(-1, 1)) {
            val ex = (18 + s * 7 + cur[1] * 1.6f) * u
            val ey = (21 + cur[2] * 1.2f) * u
            rect.set(ex - 2.4f * u, ey - ry * u, ex + 2.4f * u, ey + ry * u)
            cv.drawOval(rect, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * u
        p.strokeCap = Paint.Cap.ROUND
        path.reset()
        path.moveTo(15 * u, 28 * u)
        path.quadTo(18 * u, (28 + cur[3] * 3.2f) * u, 21 * u, 28 * u)
        cv.drawPath(path, p)
        cv.restore()
    }
}
