package studio.koto.island

/** Command table: phrases per command (RU / UK / EN). Pure Kotlin (no Android classes) so it is unit-tested. Specific commands first, generic "open <app>" last. */
object Cmds {
    class Spec(val id: String, val cat: String, val re: Regex)

    private const val W = "[\\p{L}']*"   // explicit Unicode letters: \w is ASCII-only on the JVM
    private fun s(id: String, cat: String, p: String) = Spec(id, cat, Regex(p))

    val all = listOf(
        // A. phone
        s("torch_off", "phone", "(?:выключи|вимкни|turn off)\\s+(?:фонарик|ліхтарик|flashlight)"),
        s("torch_on", "phone", "(?:включи|увімкни|вмикни|turn on)\\s+(?:фонарик|ліхтарик|flashlight)"),
        s("saver", "phone", "энергосбережени|економ$W\\s+(?:заряд|енергі)|battery saver|power saving"),
        s("phone_info", "phone", "информаци$W\\s+о\\s+телефоне|інформаці$W\\s+про\\s+телефон|phone info|about (?:the )?phone"),
        s("storage", "phone", "свободн$W\\s+памят|вільн$W\\s+пам'?ят|free (?:memory|storage|space)"),
        s("net", "phone", "проверь интернет|перевір$W\\s+інтернет|check (?:the )?internet"),
        s("wifi", "phone", "(?:настройки|налаштування|settings)\\s+(?:wi-?fi|вай-?фай)|wi-?fi settings"),
        s("bt", "phone", "(?:настройки|налаштування|settings)\\s+(?:bluetooth|блютуз|блютус)|bluetooth settings"),
        s("mobile", "phone", "мобильн$W\\s+сет|мобільн$W\\s+мереж|mobile network"),
        s("dnd", "phone", "не беспокоить|не турбувати|do not disturb"),
        // web / apps
        s("search", "web", "^(?:напиши в браузере|найди в браузере|найди в интернете|напиши в браузері|знайди в браузері|search (?:the )?(?:web|browser) for|write in (?:the )?browser)\\s+(.+)$"),
        s("yt_search", "web", "^(?:открой |запусти |відкрий |open )?(?:ютуб|ютюб|youtube)\\s+(.+)$"),
        s("twitch", "web", "^(?:открой |запусти |відкрий |open |launch )?(?:твич|twitch)$"),
        // B. productivity
        s("calendar", "tools", "календар|calendar"),
        s("days_until", "tools", "(?:сколько дней до|скільки днів до|how many days (?:until|to)|days until)\\s+(\\S+)"),
        // C. music
        s("pause", "music", "пауз|pause|останови музык|зупини музик"),
        s("play", "music", "^(?:продолжи|возобнови|продовж|поновити|resume|continue|play)\\s+(?:музык|музик|music)"),
        s("next", "music", "следующ$W\\s+трек|наступн$W\\s+трек|next (?:track|song)"),
        s("prev", "music", "предыдущ$W\\s+трек|попередн$W\\s+трек|previous (?:track|song)"),
        s("player", "music", "музыкальн$W\\s+плеер|музичн$W\\s+плеєр|music player"),
        s("volume_ui", "music", "панел$W\\s+громкости|панел$W\\s+гучності|volume panel|show volume"),
        // D. Tamagotchi
        s("pet_feed", "pet", "покорми\\s+питомц|нагодуй\\s+улюбленц|feed\\s+(?:the |my )?pet"),
        s("pet_play", "pet", "поиграй\\s+с\\s+питомц|пограй\\s+з\\s+улюбленц|play\\s+with\\s+(?:the |my )?pet"),
        s("pet_stats", "pet", "статистик$W\\s+питомц|статистик$W\\s+улюбленц|pet\\s+stat"),
        s("pet_sleep", "pet", "уложи\\s+питомц$W\\s+спать|поклади\\s+улюбленц$W\\s+спати|put\\s+(?:the |my )?pet\\s+to\\s+sleep"),
        s("pet_wake", "pet", "разбуди\\s+питомц|розбуди\\s+улюбленц|wake\\s+(?:up\\s+)?(?:the |my )?pet"),
        s("pet_look", "pet", "смени\\s+внешний\\s+вид|змін$W\\s+вигляд|change\\s+(?:the\\s+)?(?:pet\\s+)?look"),
        s("pet_mood", "pet", "настроени$W\\s+у\\s+питомц|настрій\\s+у\\s+улюбленц|pet\\s+mood|mood\\s+of\\s+(?:the |my )?pet"),
        // E. island (compact = collapsed, extended = expanded)
        s("island_collapse", "island", "(?:сверни|згорни|collapse|minimi[sz]e)\\s+(?:остров|острів|island)|компактн$W\\s+режим|compact mode"),
        s("island_expand", "island", "(?:разверни|розгорни|expand)\\s+(?:остров|острів|island)|расширенн$W\\s+режим|розширен$W\\s+режим|extended mode"),
        s("island_left", "island", "(?:перемести|перемісти|move)\\s+(?:остров|острів|island)\\s+(?:влево|вліво|ліворуч|left)"),
        s("island_right", "island", "(?:перемести|перемісти|move)\\s+(?:остров|острів|island)\\s+(?:вправо|праворуч|right)"),
        // info
        s("time", "info", "который час|скільки часу|котра година|what time"),
        s("date", "info", "какая сегодня дата|какое сегодня число|яка сьогодні дата|today'?s date|what'?s the date"),
        s("battery", "info", "батаре|заряд|battery"),
        s("help", "info", "что ты умеешь|що ти вмієш|what can you do"),
        s("open_app", "apps", "^(?:открой|запусти|відкрий|open|launch)\\s+(.+)$")
    )

    fun clean(raw: String) = raw.trim().lowercase()
        .replace(Regex("^(?:котость|котосте|kotosty)[,!.\\s]*|^(?:кото|коте|koto)[,!.\\s]+"), "").trim()

    fun match(q: String): Pair<Spec, MatchResult>? {
        for (c in all) c.re.find(q)?.let { return c to it }
        return null
    }
}
