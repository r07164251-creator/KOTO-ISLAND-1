package studio.koto.island

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.DateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

/**
 * Single command pipeline for the overlay mic and the in-app mic:
 * recognized text -> Cmds (phrases) -> permission check -> execute -> reply -> history.
 * handled=false means "not a system command": the caller hands it to the web layer (math / notes / AI).
 */
class CommandEngine(private val c: Context) {
    class Res(val handled: Boolean, val reply: String = "", val ok: Boolean = true, val name: String = "")

    companion object {
        @Volatile private var lastQ = ""
        @Volatile private var lastAt = 0L
        private val DAYS = listOf("пон" to 1, "вів" to 2, "вто" to 2, "сре" to 3, "сер" to 3, "чет" to 4, "пят" to 5, "п'я" to 5, "суб" to 6, "вос" to 7, "нед" to 7,
            "mon" to 1, "tue" to 2, "wed" to 3, "thu" to 4, "fri" to 5, "sat" to 6, "sun" to 7)
        private val PALETTE = intArrayOf(0xFFF2EFFF.toInt(), 0xFFFFD43B.toInt(), 0xFF7DD3FC.toInt(), 0xFFC4B5FD.toInt(), 0xFFFDA4AF.toInt(), 0xFF86EFAC.toInt())
    }

    private val sp = c.getSharedPreferences("koto", Context.MODE_PRIVATE)
    val lang: String get() = sp.getString("lang", "ru") ?: "ru"
    fun tag() = when (lang) { "uk" -> "uk-UA"; "en" -> "en-US"; else -> "ru-RU" }
    fun tr(ru: String, uk: String, en: String) = when (lang) { "uk" -> uk; "en" -> en; else -> ru }
    private fun fmt() = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
    fun err(n: String) { sp.edit().putString("lasterr", "$n @ ${fmt()}").apply() }
    private fun audio() = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun run(raw: String): Res {
        val q = Cmds.clean(raw)
        val now = System.currentTimeMillis()
        if (q.isNotEmpty() && q == lastQ && now - lastAt < 2500) return Res(true)   // the same phrase twice in a row = one execution
        lastQ = q; lastAt = now
        val r = try { exec(q) } catch (e: SecurityException) {
            Res(true, tr("Нет доступа к этому действию", "Немає доступу до цієї дії", "Action not allowed"), false, "denied")
        }
        if (r.handled && r.name.isNotEmpty()) {
            val a = JSONArray(sp.getString("hist", "[]"))
            a.put(JSONObject().put("t", now).put("heard", raw.take(120)).put("cmd", r.name).put("ok", r.ok))
            val keep = JSONArray()
            for (i in maxOf(0, a.length() - 30) until a.length()) keep.put(a.get(i))
            sp.edit().putString("hist", keep.toString()).apply()
            if (!r.ok) err(r.name)
        }
        return r
    }

    private fun exec(q: String): Res {
        val (spec, m) = Cmds.match(q) ?: return Res(false)
        val a = if (m.groupValues.size > 1) m.groupValues[1].trim() else ""
        return when (spec.id) {
            "search" -> web("https://www.google.com/search?q=" + enc(a))
            "yt_search" -> yt(a)
            "twitch" -> twitch()
            "open_app" -> open(a)
            "time" -> Res(true, DateFormat.getTimeInstance(DateFormat.SHORT, Locale.forLanguageTag(tag())).format(Date()), true, "time")
            "date" -> Res(true, DateFormat.getDateInstance(DateFormat.LONG, Locale.forLanguageTag(tag())).format(Date()), true, "date")
            "battery" -> Res(true, "${(c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%", true, "battery")
            "help" -> Res(true, tr("Фонарик, музыка (пауза, дальше), питомец (покорми), остров (сверни), поиск в браузере, Ютуб, Twitch, время, батарея", "Ліхтарик, музика (пауза, далі), улюбленець (нагодуй), острів (згорни), пошук у браузері, Ютуб, Twitch, час, батарея", "Flashlight, music (pause, next), pet (feed), island (collapse), browser search, YouTube, Twitch, time, battery"), true, "help")
            "torch_on" -> torch(true)
            "torch_off" -> torch(false)
            "saver" -> settings(Settings.ACTION_BATTERY_SAVER_SETTINGS, "saver")
            "wifi" -> settings(Settings.ACTION_WIFI_SETTINGS, "wifi")
            "bt" -> settings(Settings.ACTION_BLUETOOTH_SETTINGS, "bt")
            "phone_info" -> Res(true, "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", true, "phone_info")
            "storage" -> storage()
            "net" -> net(false)
            "mobile" -> net(true)
            "dnd" -> dnd()
            "calendar" -> { val ok = view("content://com.android.calendar/time/" + System.currentTimeMillis()); Res(true, if (ok) "📅" else tr("Календарь не найден", "Календар не знайдено", "No calendar app"), ok, "calendar") }
            "days_until" -> daysUntil(a)
            "pause" -> key(KeyEvent.KEYCODE_MEDIA_PAUSE, "pause")
            "play" -> key(KeyEvent.KEYCODE_MEDIA_PLAY, "play")
            "next" -> key(KeyEvent.KEYCODE_MEDIA_NEXT, "next")
            "prev" -> key(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "prev")
            "player" -> player()
            "volume_ui" -> { audio().adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI); Res(true, "🔊", true, "volume_ui") }
            "pet_feed", "pet_play", "pet_stats", "pet_sleep", "pet_wake", "pet_look", "pet_mood" -> pet(spec.id)
            "island_collapse", "island_expand", "island_left", "island_right" -> island(spec.id.removePrefix("island_"))
            else -> Res(false)
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s.trim().take(200), "UTF-8")

    private fun view(url: String, pkg: String? = null): Boolean {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.setPackage(pkg)
        return try { c.startActivity(i); true } catch (e: ActivityNotFoundException) { false }
    }

    private fun web(url: String): Res {
        val ok = view(url)
        return Res(true, if (ok) "✓" else tr("Браузер не найден", "Браузер не знайдено", "No browser found"), ok, "search")
    }

    private fun yt(q: String): Res {
        val u = "https://www.youtube.com/results?search_query=" + enc(q)
        val ok = view(u, "com.google.android.youtube") || view(u)   // app first, browser if YouTube is missing
        return Res(true, if (ok) "YouTube: " + q.take(30) else tr("Не удалось открыть YouTube", "Не вдалося відкрити YouTube", "Can't open YouTube"), ok, "youtube_search")
    }

    private fun twitch(): Res {
        val i = c.packageManager.getLaunchIntentForPackage("tv.twitch.android.app")
        val ok = if (i != null) { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } else view("https://www.twitch.tv")
        return Res(true, if (ok) "Twitch" else tr("Не удалось открыть Twitch", "Не вдалося відкрити Twitch", "Can't open Twitch"), ok, "twitch")
    }

    private fun open(a: String): Res {
        if (Regex("заметк|нотатк|^notes?$|центр активн|activity center|центр активності|quick|быстр|швидк").containsMatchIn(a)) return Res(false)   // in-app screens: web layer
        val pm = c.packageManager
        val key = mapOf("ютуб" to "youtube", "ютюб" to "youtube", "хром" to "chrome", "настройки" to "settings", "налаштування" to "settings")[a] ?: a
        val names = if (key == "settings") listOf("settings", "настройки", "налаштування") else listOf(key)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { ri -> val l = ri.loadLabel(pm).toString().lowercase(); names.any { l.contains(it) } }
        val i = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (i == null) return Res(true, tr("Мур, я не нашёл это приложение", "Мур, я не знайшов цей застосунок", "Purr, I couldn't find that app"), false, "open_app")
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return Res(true, "✓ " + a.take(24), true, "open_app")
    }

    private fun settings(action: String, id: String): Res {
        return try {
            c.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); Res(true, "⚙", true, id)
        } catch (e: ActivityNotFoundException) {
            Res(true, tr("Экран настроек недоступен", "Екран налаштувань недоступний", "Settings screen unavailable"), false, id)
        }
    }

    private fun torch(on: Boolean): Res {
        val id = if (on) "torch_on" else "torch_off"
        return try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cam = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                ?: return Res(true, tr("На устройстве нет фонарика", "На пристрої немає ліхтарика", "No flashlight on this device"), false, id)
            cm.setTorchMode(cam, on)
            Res(true, if (on) "🔦 ON" else "🔦 OFF", true, id)
        } catch (e: CameraAccessException) {
            Res(true, tr("Камера занята, фонарик недоступен", "Камера зайнята, ліхтарик недоступний", "Camera in use, flashlight unavailable"), false, id)
        }
    }

    private fun storage(): Res {
        val free = StatFs(Environment.getDataDirectory().path).availableBytes / 1_073_741_824.0
        val mi = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return Res(true, "${"%.1f".format(free)} GB · RAM ${mi.availMem / 1_048_576} MB", true, "storage")
    }

    private fun net(cell: Boolean): Res {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val mobile = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        if (cell) return Res(true, if (mobile) tr("Мобильная сеть: активна", "Мобільна мережа: активна", "Mobile network: active") else tr("Мобильная сеть не используется", "Мобільна мережа не використовується", "Mobile network is not in use"), true, "mobile")
        return Res(true, if (online) "✓ " + (if (wifi) "Wi-Fi" else if (mobile) tr("мобильная сеть", "мобільна мережа", "mobile") else "OK") else tr("✗ Интернета нет", "✗ Інтернету немає", "✗ No internet"), online, "net")
    }

    private fun dnd(): Res {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            return Res(true, "🌙 " + tr("Не беспокоить включён", "Не турбувати увімкнено", "Do Not Disturb on"), true, "dnd")
        }
        settings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, "dnd")
        return Res(true, tr("Нужен доступ «Не беспокоить» — выдай его KOTO ISLAND", "Потрібен доступ «Не турбувати» — надай його KOTO ISLAND", "Allow Do Not Disturb access for KOTO ISLAND"), false, "dnd")
    }

    private fun daysUntil(w: String): Res {
        val d = DAYS.firstOrNull { w.startsWith(it.first) }?.second
            ?: return Res(true, tr("Не понял день недели", "Не зрозумів день тижня", "Unknown weekday"), false, "days_until")
        val n = (d - LocalDate.now().dayOfWeek.value + 7) % 7
        return Res(true, if (n == 0) tr("Это сегодня!", "Це сьогодні!", "That's today!") else tr("Дней: $n", "Днів: $n", "Days: $n"), true, "days_until")
    }

    // Media keys go to the active media session. Not every third-party player reacts to them.
    private fun key(code: Int, id: String): Res {
        val am = audio()
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return Res(true, "🎵", true, id)
    }

    private fun player(): Res {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(i); Res(true, "🎵", true, "player") } catch (e: ActivityNotFoundException) {
            Res(true, tr("Музыкальный плеер не найден", "Музичний плеєр не знайдено", "No music player found"), false, "player")
        }
    }

    private fun island(a: String): Res {
        val s = OverlayService.inst ?: return Res(true, tr("Остров не запущен", "Острів не запущено", "Island is not running"), false, "island_$a")
        s.cmd(a)
        return Res(true, "✓", true, "island_$a")
    }

    // Pet commands change the real saved state (same prefs the overlay reads).
    private fun pet(id: String): Res {
        if (!sp.getBoolean("pet", false)) return Res(true, tr("Питомец выключен: включи его в настройках Котости", "Улюбленець вимкнений: увімкни його в налаштуваннях Котості", "Pet is off: enable it in Kotosty settings"), false, id)
        val now = System.currentTimeMillis()
        val food = sp.getFloat("pet_food", 1f)
        val e = sp.edit()
        val pct = { f: Float -> (f * 100).toInt() }
        val text = when (id) {
            "pet_feed" -> { val f = (food + .35f).coerceAtMost(1f); e.putFloat("pet_food", f).putLong("pet_t", now); tr("Ням! Сытость ${pct(f)}%", "Ням! Ситість ${pct(f)}%", "Yum! Fullness ${pct(f)}%") }
            "pet_play" -> { e.putLong("pet_touch", now).putFloat("pet_food", (food - .03f).coerceAtLeast(0f)).putLong("pet_t", now); OverlayService.inst?.react(10); tr("Мур! Поиграли 🧶", "Мур! Погралися 🧶", "Purr! Played 🧶") }
            "pet_sleep" -> { e.putBoolean("pet_sleep", true); tr("Котость уснул 💤", "Котость заснув 💤", "Kotosty fell asleep 💤") }
            "pet_wake" -> { e.putBoolean("pet_sleep", false); tr("Котость проснулся", "Котость прокинувся", "Kotosty woke up") }
            "pet_look" -> {
                val next = PALETTE[(PALETTE.indexOf(sp.getInt("kcolor", PALETTE[0])) + 1) % PALETTE.size]
                e.putInt("kcolor", next); OverlayService.inst?.recolor(); tr("Новый цвет!", "Новий колір!", "New colour!")
            }
            "pet_stats" -> tr("Сытость ${pct(food)}% · ${moodText()}", "Ситість ${pct(food)}% · ${moodText()}", "Fullness ${pct(food)}% · ${moodText()}")
            else -> moodText()
        }
        e.apply()
        OverlayService.inst?.mood()
        return Res(true, text, true, id)
    }

    private fun moodText(): String = when (OverlayService.inst?.moodId() ?: -1) {
        5 -> tr("Спит", "Спить", "Sleeping")
        6 -> tr("Голоден", "Голодний", "Hungry")
        7 -> tr("Очень голоден и недоволен", "Дуже голодний і незадоволений", "Very hungry and grumpy")
        8 -> tr("Скучает", "Нудьгує", "Bored")
        9 -> tr("Счастлив: заряжается", "Щасливий: заряджається", "Happy: charging")
        else -> tr("Доволен", "Задоволений", "Content")
    }
}
