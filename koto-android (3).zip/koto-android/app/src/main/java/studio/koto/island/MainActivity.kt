package studio.koto.island

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.IntentFilter
import android.media.AudioManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

const val HOST = "appassets.androidplatform.net"

/** API key lives in process memory only; never written to disk. */
object Mem { @Volatile var key = ""; @Volatile var pending = "" }

/** Serves bundled assets over https://HOST and blocks navigation to any other site. */
fun assetClient(c: Context): WebViewClient {
    val loader = WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(c)).build()
    return object : WebViewClient() {
        override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = r.url.host != HOST
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var sr: SpeechRecognizer? = null
    private var lang = "en-US"

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) listen() else send("voice", JSONObject().put("s", "denied"))
    }

    // Permission request started from the overlay mic; the user taps the overlay mic again afterwards.
    private val micAsk = registerForActivityResult(ActivityResultContracts.RequestPermission()) { g ->
        if (g && OverlayService.running) ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        else if (!g && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO))
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun handle(i: Intent?) {
        i ?: return
        i.getStringExtra("cmd")?.let { Mem.pending = it.take(300); i.removeExtra("cmd") }
        if (i.getBooleanExtra("mic", false)) { i.removeExtra("mic"); micAsk.launch(Manifest.permission.RECORD_AUDIO) }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); handle(i); if (::web.isInitialized) send("resume", JSONObject()) }

    private fun send(ev: String, o: JSONObject) {
        web.post { web.evaluateJavascript("window.onKoto&&window.onKoto(${JSONObject.quote(ev)},$o)", null) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.webViewClient = assetClient(this)
        web.addJavascriptInterface(Bridge(), "KotoNative")
        web.loadUrl("https://$HOST/assets/index.html")
        handle(intent)
    }

    // Web layer re-checks permissions every time the user comes back (e.g. from system Settings).
    override fun onResume() { super.onResume(); if (::web.isInitialized) send("resume", JSONObject()) }

    override fun onDestroy() { sr?.destroy(); web.destroy(); super.onDestroy() }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { send("voice", JSONObject().put("s", "unavailable")); return }
        val r = sr ?: SpeechRecognizer.createSpeechRecognizer(this).also { sr = it }   // reuse: creating it is the slow part
        r.setRecognitionListener(object : RecognitionListener {
            fun txt(b: Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            override fun onReadyForSpeech(p: Bundle?) = send("voice", JSONObject().put("s", "listening"))
            override fun onPartialResults(p: Bundle?) = send("voice", JSONObject().put("s", "partial").put("text", txt(p)))
            override fun onResults(p: Bundle?) = send("voice", JSONObject().put("s", "result").put("text", txt(p)))
            override fun onEndOfSpeech() = send("voice", JSONObject().put("s", "processing"))
            override fun onError(e: Int) { if (e == 5 || e == 8) { sr?.destroy(); sr = null }; send("voice", JSONObject().put("s", "error").put("code", e)) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
        )
    }

    /** Whitelisted actions only; every argument is validated. Microphone starts only on explicit startVoice(). */
    inner class Bridge {
        @JavascriptInterface fun overlay() = if (Settings.canDrawOverlays(this@MainActivity)) "granted" else "denied"

        @JavascriptInterface fun requestOverlay() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun startOverlay(): Boolean {
            if (!Settings.canDrawOverlays(this@MainActivity)) return false
            ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, OverlayService::class.java))
            return true
        }

        @JavascriptInterface fun stopOverlay() { stopService(Intent(this@MainActivity, OverlayService::class.java)) }

        @JavascriptInterface fun mic() =
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) "granted" else "denied"

        @JavascriptInterface fun startVoice(l: String) = runOnUiThread {
            if (l in setOf("ru-RU", "uk-UA", "en-US")) lang = l
            if (mic() == "granted") listen() else micPerm.launch(Manifest.permission.RECORD_AUDIO)
        }

        @JavascriptInterface fun stopVoice() = runOnUiThread { sr?.stopListening() }

        @JavascriptInterface fun openApp(q: String): Boolean {
            val n = q.trim().lowercase().take(60)
            if (n.isEmpty()) return false
            val pm = packageManager
            @Suppress("DEPRECATION")
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) } ?: return false
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
            runOnUiThread { startActivity(i) }
            return true
        }

        @JavascriptInterface fun battery() =
            (getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        @JavascriptInterface fun setKey(k: String) { Mem.key = k.take(400) }

        private val sp = getSharedPreferences("koto", Context.MODE_PRIVATE)
        private val eng by lazy { CommandEngine(applicationContext) }
        private val am: AudioManager get() = getSystemService(AUDIO_SERVICE) as AudioManager
        private val nm: NotificationManager get() = getSystemService(NotificationManager::class.java)
        @JavascriptInterface fun quick(): String {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val sc = maxOf(1, b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
            val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            return JSONObject()
                .put("bat", lv * 100 / sc)
                .put("chg", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
                .put("vol", am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / maxOf(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)))
                .put("ring", am.ringerMode)
                .put("br", Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255)
                .put("canWrite", Settings.System.canWrite(this@MainActivity))
                .toString()
        }
        @JavascriptInterface fun setVolume(p: Int) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, p.coerceIn(0, 100) * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 100, 0)
        }
        @JavascriptInterface fun setRinger(m: Int): Boolean {
            if (m !in 0..2) return false
            if (m == AudioManager.RINGER_MODE_SILENT && !nm.isNotificationPolicyAccessGranted) return false   // Android needs Do Not Disturb access for silent
            am.ringerMode = m
            return true
        }
        @JavascriptInterface fun requestDnd() = runOnUiThread { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        @JavascriptInterface fun setBrightness(p: Int): Boolean {
            if (!Settings.System.canWrite(this@MainActivity)) return false
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p.coerceIn(1, 100) * 255 / 100)
            return true
        }
        @JavascriptInterface fun requestWrite() = runOnUiThread { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        @JavascriptInterface fun setColor(h: String) {
            if (Regex("^#[0-9a-fA-F]{6}$").matches(h)) { sp.edit().putInt("kcolor", android.graphics.Color.parseColor(h)).apply(); OverlayService.inst?.recolor() }
        }
        @JavascriptInterface fun pet(): String = JSONObject().put("food", sp.getFloat("pet_food", 1f).toDouble()).toString()
        @JavascriptInterface fun takePending(): String { val p = Mem.pending; Mem.pending = ""; return p }
        @JavascriptInterface fun command(t: String): String {
            val r = eng.run(t.take(300))
            return JSONObject().put("handled", r.handled).put("reply", r.reply).put("ok", r.ok).toString()
        }
        @JavascriptInterface fun setLang(l: String) { if (l in setOf("ru", "uk", "en")) sp.edit().putString("lang", l).apply() }
        @JavascriptInterface fun getPref(k: String) = sp.getBoolean(k, k == "haptic" || k == "petvib")
        @JavascriptInterface fun setPref(k: String, v: Boolean) { if (k in setOf("lock", "haptic", "pet", "petvib")) { sp.edit().putBoolean(k, v).apply(); if (k == "pet") OverlayService.inst?.mood() } }
        @JavascriptInterface fun resetPos() { OverlayService.inst?.reset() }
        @JavascriptInterface fun history(): String = sp.getString("hist", "[]") ?: "[]"
        @JavascriptInterface fun clearHistory() { sp.edit().remove("hist").apply() }
        @JavascriptInterface fun diag(): String = JSONObject()
            .put("running", OverlayService.running)
            .put("overlay", Settings.canDrawOverlays(this@MainActivity))
            .put("mic", mic() == "granted")
            .put("speech", SpeechRecognizer.isRecognitionAvailable(this@MainActivity))
            .put("err", sp.getString("lasterr", "")).toString()
    }
}
