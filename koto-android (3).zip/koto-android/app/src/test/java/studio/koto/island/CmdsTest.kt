package studio.koto.island

import org.junit.Assert.assertEquals
import org.junit.Test

class CmdsTest {
    @Test fun phrasesMapToCommands() {
        val cases = mapOf(
            "включи фонарик" to "torch_on", "выключи фонарик" to "torch_off", "включи энергосбережение" to "saver",
            "покажи информацию о телефоне" to "phone_info", "сколько свободной памяти?" to "storage", "проверь интернет" to "net",
            "открой настройки Wi-Fi" to "wifi", "открой настройки Bluetooth" to "bt", "покажи состояние мобильной сети" to "mobile",
            "включи режим не беспокоить" to "dnd", "открой календарь" to "calendar", "сколько дней до пятницы?" to "days_until",
            "поставь музыку на паузу" to "pause", "продолжи музыку" to "play", "следующий трек" to "next", "предыдущий трек" to "prev",
            "открой музыкальный плеер" to "player", "покажи панель громкости" to "volume_ui",
            "покорми питомца" to "pet_feed", "поиграй с питомцем" to "pet_play", "покажи статистику питомца" to "pet_stats",
            "уложи питомца спать" to "pet_sleep", "разбуди питомца" to "pet_wake", "смени внешний вид питомца" to "pet_look",
            "какое сейчас настроение у питомца?" to "pet_mood", "сверни остров" to "island_collapse", "разверни остров" to "island_expand",
            "перемести остров влево" to "island_left", "перемести остров вправо" to "island_right",
            "включи компактный режим" to "island_collapse", "включи расширенный режим" to "island_expand",
            "открой youtube" to "open_app", "ютуб вилли" to "yt_search", "напиши в браузере как сделать игру" to "search", "твич" to "twitch",
            "который час" to "time", "что ты умеешь" to "help"
        )
        for ((phrase, id) in cases) assertEquals(phrase, id, Cmds.match(Cmds.clean("Кото, $phrase"))?.first?.id)
    }

    @Test fun questionsAreNotCommands() {
        assertEquals(null, Cmds.match(Cmds.clean("расскажи интересный факт")))
    }
}
